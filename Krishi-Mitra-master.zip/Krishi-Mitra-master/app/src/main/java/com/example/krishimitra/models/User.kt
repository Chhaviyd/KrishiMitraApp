package com.example.krishimitra.models

data class User(
    var name : String = "",
    var username : String = "",
    var phone : String = "",
    var email : String = "",
    var location : String = "",
    var password : String = ""
)