package com.sunayanpradhan.weatherapptutorial.Models

data class Rain(
    val `1h`: Double
)