package com.example.krishimitra.models

class TaskItem( val id: String = "",
                val description: String = "",
                val time: String = "",
                val date: String = "")