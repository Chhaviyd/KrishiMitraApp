package com.sunayanpradhan.weatherapptutorial.Models

data class Coord(
    val lat: Double,
    val lon: Double
)