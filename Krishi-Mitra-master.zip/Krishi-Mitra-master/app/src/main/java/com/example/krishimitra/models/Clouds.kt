package com.sunayanpradhan.weatherapptutorial.Models

data class Clouds(
    val all: Int
)