package com.example.krishimitra.models

data class chatMessage(val message: String, val isBotMessage: Boolean)

